# stefiont
My handwriting made into a basic font with 4 glyphs to each character for more authentic handwriting

<img width="173" alt="font name in the font" src="https://github.com/stefior/stefiont/assets/43305255/5bfd221d-8414-4eb8-b9b6-9bd7613d60cd">
<img width="1074" alt="example paragraph" src="https://github.com/stefior/stefiont/assets/43305255/bccb3001-8cef-4e02-ab03-58bef29f19e8">
